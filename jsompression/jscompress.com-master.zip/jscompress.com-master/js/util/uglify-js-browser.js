// eslint-disable-next-line import/no-unresolved, import/extensions, import/no-webpack-loader-syntax
import { UglifyJS } from 'exports-loader?type=commonjs&exports=UglifyJS!uglify-js/uglify-js-browser';

export default UglifyJS;
