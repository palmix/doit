export let useECMAScriptNext = false;
export const setUseECMAScriptNext = (value) => {
  useECMAScriptNext = value;
};
